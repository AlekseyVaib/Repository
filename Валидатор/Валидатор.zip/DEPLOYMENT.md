# Инструкция по развертыванию SaaS версии Валидатора 3000

## Обзор

Это руководство поможет вам развернуть веб-версию валидатора email адресов на сервере. Приложение использует Flask и может работать на различных платформах.

## Структура проекта

```
Валидатор/
├── app.py                 # Flask приложение
├── email_validator.py     # Основной модуль валидатора (не трогаем)
├── templates/
│   └── index.html        # Главная страница
├── static/
│   ├── css/
│   │   └── style.css     # Стили
│   └── js/
│       └── main.js       # JavaScript
├── uploads/              # Папка для загруженных файлов (создается автоматически)
├── results/              # Папка для результатов (создается автоматически)
├── requirements_web.txt  # Зависимости для веб-версии
└── DEPLOYMENT.md         # Этот файл
```

## Шаг 1: Подготовка сервера

### Вариант A: VPS сервер (Linux)

1. **Подключитесь к серверу по SSH:**
   ```bash
   ssh username@your-server-ip
   ```

2. **Обновите систему:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

3. **Установите Python 3.9+ и pip:**
   ```bash
   sudo apt install python3 python3-pip python3-venv -y
   ```

4. **Установите Nginx (для проксирования):**
   ```bash
   sudo apt install nginx -y
   ```

### Вариант B: Облачный сервис (Heroku, Railway, Render)

Следуйте инструкциям конкретного сервиса. Обычно они автоматически определяют Python приложения.

## Шаг 2: Загрузка кода на сервер

### Вариант A: VPS через Git

1. **Установите Git:**
   ```bash
   sudo apt install git -y
   ```

2. **Клонируйте репозиторий или загрузите файлы:**
   ```bash
   # Если используете Git
   git clone your-repository-url
   cd Валидатор
   
   # Или загрузите файлы через SCP/SFTP
   ```

### Вариант B: Облачный сервис

Обычно подключается через Git репозиторий или загрузку файлов через веб-интерфейс.

## Шаг 3: Установка зависимостей

1. **Создайте виртуальное окружение:**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # Linux/Mac
   # или
   venv\Scripts\activate     # Windows
   ```

2. **Установите зависимости:**
   ```bash
   pip install -r requirements_web.txt
   ```

3. **Убедитесь, что все зависимости установлены:**
   ```bash
   pip list
   ```

## Шаг 4: Настройка приложения

1. **Создайте файл `.env` для переменных окружения (опционально):**
   ```bash
   SECRET_KEY=your-secret-key-here-change-this
   FLASK_ENV=production
   ```

2. **Или установите переменные окружения:**
   ```bash
   export SECRET_KEY="your-secret-key-here"
   export FLASK_ENV="production"
   ```

## Шаг 5: Запуск приложения

### Вариант A: Разработка (локально)

```bash
python app.py
```

Приложение будет доступно по адресу: `http://localhost:5000`

### Вариант B: Продакшен с Gunicorn (VPS)

1. **Установите Gunicorn:**
   ```bash
   pip install gunicorn
   ```

2. **Запустите приложение:**
   ```bash
   gunicorn -w 4 -b 0.0.0.0:5000 --timeout 120 app:app
   ```

   Параметры:
   - `-w 4` - количество воркеров (по количеству CPU ядер)
   - `-b 0.0.0.0:5000` - адрес и порт
   - `--timeout 120` - таймаут для длительных операций
   - `app:app` - модуль и приложение Flask

3. **Для постоянной работы используйте systemd:**

   Создайте файл `/etc/systemd/system/validator.service`:
   ```ini
   [Unit]
   Description=Email Validator SaaS
   After=network.target

   [Service]
   User=your-username
   WorkingDirectory=/path/to/Валидатор
   Environment="PATH=/path/to/Валидатор/venv/bin"
   ExecStart=/path/to/Валидатор/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 --timeout 120 app:app

   [Install]
   WantedBy=multi-user.target
   ```

   Активируйте сервис:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable validator
   sudo systemctl start validator
   sudo systemctl status validator
   ```

### Вариант C: Облачный сервис

Обычно автоматически определяет и запускает приложение. Убедитесь, что:
- Указан правильный файл запуска (`app.py`)
- Установлены все зависимости из `requirements_web.txt`
- Настроены переменные окружения

## Шаг 6: Настройка Nginx (для VPS)

1. **Создайте конфигурацию Nginx:**

   Создайте файл `/etc/nginx/sites-available/validator`:
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;  # Замените на ваш домен

       client_max_body_size 50M;  # Максимальный размер загружаемого файла

       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_read_timeout 300s;
           proxy_connect_timeout 300s;
       }

       location /static {
           alias /path/to/Валидатор/static;
       }
   }
   ```

2. **Активируйте конфигурацию:**
   ```bash
   sudo ln -s /etc/nginx/sites-available/validator /etc/nginx/sites-enabled/
   sudo nginx -t  # Проверка конфигурации
   sudo systemctl reload nginx
   ```

3. **Настройте SSL (рекомендуется):**
   ```bash
   sudo apt install certbot python3-certbot-nginx -y
   sudo certbot --nginx -d your-domain.com
   ```

## Шаг 7: Настройка файрвола (для VPS)

```bash
# Разрешить HTTP и HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Разрешить SSH (если еще не разрешен)
sudo ufw allow 22/tcp

# Включить файрвол
sudo ufw enable
```

## Шаг 8: Проверка работы

1. **Откройте браузер и перейдите на ваш домен или IP адрес**

2. **Проверьте:**
   - Загрузка файла работает
   - Валидация запускается
   - Результаты скачиваются

3. **Проверьте логи:**
   ```bash
   # Логи приложения
   tail -f /path/to/Валидатор/email_validator.log
   
   # Логи Gunicorn (если используется systemd)
   sudo journalctl -u validator -f
   
   # Логи Nginx
   sudo tail -f /var/log/nginx/access.log
   sudo tail -f /var/log/nginx/error.log
   ```

## Безопасность

### Рекомендации для продакшена:

1. **Измените SECRET_KEY:**
   ```python
   # В app.py или через переменную окружения
   app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'сгенерируйте-случайный-ключ')
   ```

2. **Ограничьте размер файлов:**
   ```python
   app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50 MB
   ```

3. **Настройте CORS (если нужно):**
   ```python
   from flask_cors import CORS
   CORS(app, resources={r"/api/*": {"origins": "https://your-domain.com"}})
   ```

4. **Добавьте rate limiting:**
   ```python
   from flask_limiter import Limiter
   limiter = Limiter(app, key_func=get_remote_address)
   
   @app.route('/api/upload', methods=['POST'])
   @limiter.limit("10 per minute")
   def upload_file():
       ...
   ```

5. **Регулярно очищайте старые файлы:**
   ```bash
   # Добавьте в crontab для очистки файлов старше 7 дней
   0 2 * * * find /path/to/Валидатор/uploads -type f -mtime +7 -delete
   0 2 * * * find /path/to/Валидатор/results -type f -mtime +7 -delete
   ```

## Масштабирование

### Для больших нагрузок:

1. **Используйте Redis для хранения задач:**
   ```python
   import redis
   r = redis.Redis(host='localhost', port=6379, db=0)
   ```

2. **Используйте Celery для фоновых задач:**
   ```python
   from celery import Celery
   celery = Celery('validator', broker='redis://localhost:6379/0')
   ```

3. **Добавьте балансировщик нагрузки** (если несколько серверов)

## Мониторинг

1. **Используйте инструменты мониторинга:**
   - Prometheus + Grafana
   - Sentry для отслеживания ошибок
   - Uptime monitoring (UptimeRobot, Pingdom)

2. **Настройте алерты** на критические ошибки

## Резервное копирование

1. **Регулярно делайте бэкапы:**
   ```bash
   # Скрипт бэкапа
   tar -czf backup-$(date +%Y%m%d).tar.gz /path/to/Валидатор
   ```

2. **Настройте автоматические бэкапы** через cron

## Обновление приложения

1. **Остановите сервис:**
   ```bash
   sudo systemctl stop validator
   ```

2. **Обновите код:**
   ```bash
   git pull  # или загрузите новые файлы
   ```

3. **Обновите зависимости:**
   ```bash
   source venv/bin/activate
   pip install -r requirements_web.txt --upgrade
   ```

4. **Перезапустите сервис:**
   ```bash
   sudo systemctl start validator
   ```

## Устранение неполадок

### Приложение не запускается:
- Проверьте логи: `sudo journalctl -u validator -n 50`
- Убедитесь, что все зависимости установлены
- Проверьте права доступа к папкам `uploads/` и `results/`

### Файлы не загружаются:
- Проверьте размер файла (максимум 50 MB)
- Проверьте права на запись в папку `uploads/`
- Проверьте настройки Nginx: `client_max_body_size`

### Валидация не работает:
- Проверьте логи: `tail -f email_validator.log`
- Убедитесь, что сервер имеет доступ в интернет (для DNS/SMTP проверок)
- Проверьте таймауты в настройках

## Поддержка

При возникновении проблем:
1. Проверьте логи приложения
2. Проверьте логи веб-сервера
3. Убедитесь, что все зависимости установлены
4. Проверьте права доступа к файлам и папкам

---

**Успешного развертывания! 🚀**
